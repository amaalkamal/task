<nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3">
  <div class="container">
    <a class="navbar-brand fs-3" href="index.php">
        <strong>Php Registration system</strong>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav ms-auto">
        <a class="nav-link fs-4 mx-1" href="index.php">Home</a>
        <a class="nav-link fs-4 mx-1" href="Register.php">Register</a>
        <a class="nav-link fs-4 mx-1" href="Login.php">Log in</a>
      </div>
    </div>
  </div>
</nav>