<footer class="bg-dark text-center fixed-bottom py-3 mt-5 fs-5 text-light">
    Copyright &copy; 2023 All Right Reserved 
    <br> Your Website
</footer>