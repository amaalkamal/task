@extends('layouts.master')

@section('title' , 'Home Page')

@section('main')
    <div class="alert alert-dark text-center py-3 my-5 container w-50 fs-4">
        Home Page
    </div>
@endsection