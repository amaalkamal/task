@extends('layouts.master')

@section('title' , 'Details page')

@section('main')
    <div class="alert alert-dark text-center
     py-3 my-5 container w-50 fs-4">

     Courses Details

    </div>

    <section class="container w-50 mx-auto bg-light
     show rounded border text-center my-5 p-5">
     <h2> Course Title : {{$event->title}}</h2>
     <hr> 
    <p> Course Price : {{$event->price}} $ <br> 
        {{$event->desc}}</p>
    <div class="alert alert-secondary rounded py-3 my-3">
        Created At {{$event->created_at}} By instractor : <br>
        <strong class="text-warning">{{$event->speaker}}</strong>
    </div>
    <hr>
    <a href="/events"> Return to All Courses </a>
    </section>

@endsection