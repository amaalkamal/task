

<?php $__env->startSection('title' , 'Home Page'); ?>

<?php $__env->startSection('main'); ?>
    <div class="alert alert-dark text-center py-3 my-5 container w-50 fs-4">
        Home Page
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demoCourses\resources\views/pages/home.blade.php ENDPATH**/ ?>