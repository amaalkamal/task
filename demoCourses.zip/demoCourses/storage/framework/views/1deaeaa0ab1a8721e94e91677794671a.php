

<?php $__env->startSection('title' , 'Create Event Page'); ?>

<?php $__env->startSection('main'); ?>
    <div class="alert alert-primary text-center
     py-3 my-5 container w-50 fs-4">
        Add new course 
    </div>

    <div class="container my-5 w-50 mx-auto">
        <form action="/store" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group my-3">
                <label for="title">Course's Name :</label>
                <input type="text" class="form-control" 
                id="title" name="title"></div>
            <div class="form-group my-3">
                <label for="speaker">Course's instractor :</label>
                <input type="text" class="form-control"
                 id="speaker" name="speaker"></div>
            <div class="form-group my-3">
                <label for="price">Course price :</label>
                <input type="number" class="form-control" id="price" name="price"></div>
            <div class="form-group my-3">
                <label for="desc">course's Description :</label>
                <textarea type="text" class="form-control" id="desc" 
                name="desc"></textarea>
            </div>
            <input type="submit" value="Add Course" class="btn btn-dark my-2">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demoCourses\resources\views/pages/create.blade.php ENDPATH**/ ?>