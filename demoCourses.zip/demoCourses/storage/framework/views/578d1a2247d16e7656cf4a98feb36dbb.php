

<?php $__env->startSection('title' , 'Details page'); ?>

<?php $__env->startSection('main'); ?>
    <div class="alert alert-dark text-center
     py-3 my-5 container w-50 fs-4">

     Courses Details

    </div>

    <section class="container w-50 mx-auto bg-light
     show rounded border text-center my-5 p-5">
     <h2> Course Title : <?php echo e($event->title); ?></h2>
     <hr> 
    <p> Course Price : <?php echo e($event->price); ?> $ <br> 
        <?php echo e($event->desc); ?></p>
    <div class="alert alert-secondary rounded py-3 my-3">
        Created At <?php echo e($event->created_at); ?> By instractor : <br>
        <strong class="text-warning"><?php echo e($event->speaker); ?></strong>
    </div>
    <hr>
    <a href="/events"> Return to All Courses </a>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demoCourses\resources\views/pages/show.blade.php ENDPATH**/ ?>