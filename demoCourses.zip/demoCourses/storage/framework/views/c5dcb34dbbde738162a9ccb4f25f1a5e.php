<footer class="bg-light py-4 fs-5 text-center text-dark mt-5">
    Copyright &copy; 2023 Made With &hearts;
    <br> @ BackEndMans All Right Reserved
</footer><?php /**PATH C:\xampp\htdocs\demoCourses\resources\views/includes/footer.blade.php ENDPATH**/ ?>