

<?php $__env->startSection('title' , 'Edit Event Page'); ?>

<?php $__env->startSection('main'); ?>
    <div class="alert alert-success text-center
     py-3 my-5 container w-50 fs-4">
        Edit course 
    </div>

    <div class="container my-5 w-50 mx-auto">
        <form action="<?php echo e('/events/' . $event->id . '/update'); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group my-3">
                <label for="title">Course's Name :</label>
                <input type="text" class="form-control" 
                id="title" name="title"
                value="<?php echo e($event->title); ?>"></div>
            <div class="form-group my-3">
                <label for="speaker">Course's instractor :</label>
                <input type="text" class="form-control"
                 id="speaker" name="speaker"
                 value="<?php echo e($event->speaker); ?>"></div>
            <div class="form-group my-3">
                <label for="price">Course price :</label>
                <input type="number" class="form-control" id="price" name="price"
                value="<?php echo e($event->price); ?>"></div>
            <div class="form-group my-3">
                <label for="desc">course's Description :</label>
                <textarea type="text" class="form-control" id="desc" 
                name="desc">
                <?php echo e($event->desc); ?>

            
            </textarea>
            </div>
            <input type="submit" value="Edit Course"
             class="btn btn-success my-2">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demoCourses\resources\views/pages/edit.blade.php ENDPATH**/ ?>