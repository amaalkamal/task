<?php

//PROBLEM -->> 1 << Check The Number Is Even or Odd 

// $number=31;

// if($number % 2 == 0){
//     echo "Even";
// }

// else{
//     echo "Odd";
// }






// --------------------------------
//PROBLEM -->> 2 <<  Compute Circle Area and Circumference  

// $r =5;
// $pi =22.14;
// $Area = $pi*$r*$r;
// echo " Area is :".$Area;


// $i =10;
// $circumference = 2*$pi*$i;
// echo "  ----   Circumference is :".$circumference;





// --------------------------------
//PROBLEM -->> 3 <<  find the largest of three given integers   

// $num1=5;
// $num2=15;
// $num3=25;

// if($num1>$num2 && $num1>$num3){
//   echo $num1;
// }
// else{
//   if($num2>$num1 && $num2>$num3){
//     echo $num2;
//   }
//   else
  
//     echo $num3;
// }





// --------------------------------
//PROBLEM -->> 4 <<  Compute The sum of the numbers from 1 to 10 
// $sum=0;

// for ($i = 1; $i <= 10; $i++){

//     $sum += $i;

// }
//     echo $sum;






// --------------------------------
//PROBLEM -->> 5 <<  reverse the string " welcome" :

$str = "WELCOME";
function Reverse($str) {

    return strrev($str);

}
echo Reverse($str);