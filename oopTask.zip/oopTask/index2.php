<?php

//task 1.1


// class Circle {
//     private string $color;
//     private float $radius; 

//     public function __construct( string $color , float $radius)
//     {
//         $this->color = $color;
//         $this->radius = $radius;
//     }

//     public function getColor() : string
//     {
//         return $this->color;
//     }
//     public function getRadius() : float
//     {
//         return $this->radius;
//     }
//     public function setColor(string $color): void{
//          $this->color = $color;
//     }
//     public function setRadius(float $radius): void{
//          $this->radius = $radius;
//     }
//     public function getArea() : float{
//         return pi() * pow($this->radius , 2);
//     }
//     public function Show(){
//         // echo "radius:    " . $this->radius;
//         // echo "Area: " . $this->getArea();
//          echo "Radius = {$this->radius} <br> Area = {$this->getArea()}";

//     }

// }
// $CIR = new Circle( 'Red' ,2 );
// $CIR->setRadius(2);
// $CIR->Show();



//------------------------------------------------------------------------------------

//task 1.2



// class Circle {
//     private float $radius; 

//     public function __construct(float $radius)
//     {
//         $this->radius = $radius;
//     }

    
//     public function getRadius() : float
//     {
//         return $this->radius;
//     }
//     public function setRadius(float $radius): void{
//          $this->radius = $radius;
//     }
//     public function getArea() : float{
//         return pi() * pow($this->radius , 2);
//     }
// public function circumference() : float {
//     return pi() * $this->radius *2 ;
// }

//     public function Show(){

//          echo "Radius = {$this->radius} <br> Area = {$this->getArea()} <br> Circumference = {$this->circumference()}";

//     }

// }
// $CIR = new Circle(2.2);
// $CIR->setRadius(2.2);
// $CIR->Show();

//------------------------------------------------------------------------------------

//task 1.3


// Class Rectangle {
//     private float $width;
//     private float $height;

//     public function __construct(float $width, float $height) {
//         $this->width = $width;
//         $this->height = $height;
//     }

//     public function getwidth() : float
//      { return $this->width; }

//      public function getheight() : float
//      { return $this->height; }

//      public function setwidth(float $width) : void
//      { $this->width = $width; }

//      public function setheight(float $height) : void
//      { $this->height = $height; }

//      public function area() : float {
//         return $this->width * $this->height;
//      }

//      public function perimeter() : float {
//         return ( $this->width + $this->height ) * 2;
//      }

//      public function show()

//     {
//        echo "width = {$this->width} <br> height = {$this->height} <br> Area = {$this->Area()} <br> perimeter = {$this->perimeter()}";

//     }


// }

// $Rect = new Rectangle(3,2);
// $Rect->setwidth(3);
// $Rect->setheight(2);
// $Rect->Show();

//------------------------------------------------------------------------------------

//task 1.4

// Class Employee {

//     private int $id;
//     private int $salary;
//     private string $Fname;
//     private string $Lname;
//     public function __construct(int $id, int $salary, string $Fname,string $Lname) {

//         $this->id = $id;
//         $this->salary = $salary;
//         $this->Fname = $Fname;
//         $this->Lname = $Lname;

//     }

//     public function getid() :int { return $this->id; }
//     public function getsalary() :int { return $this->salary; }
//     public function getFname() :string { return $this->Fname; }
//     public function getLname() :string { return $this->Lname; }

//     public function setid(int $id) : void { $this->id = $id; }
//     public function setsalary (int $salary) : void { $this->salary = $salary; }
//     public function setFname (string $Fname) : void { $this->Fname = $Fname; }
//     public function setLname (string $Lname) : void { $this->Lname = $Lname; }
//     public function Name () : string { return ($this->Fname . $this->Lname); }

//     public function show()

//      {
//         echo "ID  = {$this->id} <br> First name = {$this->Fname} <br> Last name = {$this->Lname} <br> Salary = {$this->salary} <br> Name = {$this->Name()}"; }

    
// }
// $emp = new Employee(011110 ,5000 , "Ahmed" , "Yasser");
// $emp-> Show();

//---------------------------------------------------------------------------------------------------------------------------------

//task 1.5

// Class Invo {
//     private string $id;
//     private string $item;
//     private int $number;
//     private float $unitPrice;
//     public function __construct(string $id,string $item, int $number,float $unitPrice)
//     {
//         $this->id = $id;
//         $this->item = $item;
//         $this->number = $number;
//         $this->unitPrice = $unitPrice;
//     }

//     public function getid() :string { return $this->id; }
//     public function getitem() :string { return $this->item; }
//     public function getnumber() :int { return $this->number; }
//     public function getunitPrice() :float { return $this->unitPrice; }

//     public function setid(string $id) : void { $this->id = $id; }
//     public function setitem (string $item) : void { $this->item = $item; }
//     public function setnumber (int $number) : void { $this->number = $number; }
//     public function setunitPrice (float $unitPrice) : void { $this->unitPrice = $unitPrice; }
//     public function TotalPrice () : float { return ($this->number * $this->unitPrice); }
//     public function display()

//      {
//         echo "ID  = {$this->id} <br> Item = {$this->item} <br> Number of items = {$this->number} <br> Unit Item price = {$this->unitPrice} <br> TotalPrice = {$this->TotalPrice()}"; }


// }

// $inv = new Invo( "A00A", " Red pen",8,4);
// $inv->display();


//---------------------------------------------------------------------------------------------------------------------------------

//task 1.6

Class Account {
    private string $id;
    private string $name;
    private float $balance;    
    private float $amount;

        public function __construct(string $id,string $name, float $balance,float $amount)
    {
        $this->id = $id;
        $this->name = $name;
        $this->balance = $balance;
        $this->amount = $amount;

    }
    public function getid() :string { return $this->id; }
    public function getname() :string { return $this->name; }
    public function getbalance() :float { return $this->balance; }
    public function getamount() :float { return $this->amount; }


    public function setid(string $id) : void { $this->id = $id; }
    public function setname (string $name) : void { $this->name = $name; }
    public function setbalance (float $balance) : void { $this->balance = $balance; }
    public function setamount (float $amount) : void { $this->amount = $amount; }


     public function credit() : float {
        return ( $this->balance + $this->amount );
     }
     public function debit() : float {
        return ( $this->balance - $this->amount );
     }


    public function display()

     {
        echo "ID  = {$this->id} <br> Name = {$this->name} <br> balance = {$this->balance} <br> Credit = {$this->credit()} <br> Debit = {$this->debit()}"; }





}
$acc = new Account( "10000001", " Ahmed",8000 ,1000);
$acc->display();