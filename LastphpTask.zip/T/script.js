document.addEventListener('DOMContentLoaded', function () {
    const newBtn = document.getElementById('newBtn');
    const doneBtn = document.getElementById('doneBtn');
    const deleteBtn = document.getElementById('deleteBtn');
    const todoInput = document.getElementById('todoInput');
    const todoList = document.getElementById('todoList');
    const finishedList = document.getElementById('finishedList');

    newBtn.addEventListener('click', function () {
        const todoText = todoInput.value.trim();
        if (todoText !== '') {
            const li = document.createElement('li');
            li.textContent = todoText;
            todoList.appendChild(li);
            todoInput.value = '';
        }
    });

    doneBtn.addEventListener('click', function () {
        const selectedItems = document.querySelectorAll('#todoList li.selected');
        selectedItems.forEach(item => {
            todoList.removeChild(item);
            item.classList.remove('selected');
            finishedList.appendChild(item);
        });
    });

    deleteBtn.addEventListener('click', function () {
        const selectedItems = document.querySelectorAll('#todoList li.selected');
        selectedItems.forEach(item => {
            todoList.removeChild(item);
        });
    });

    todoList.addEventListener('click', function (event) {
        const li = event.target.closest('li');
        if (li) {
            li.classList.toggle('selected');
        }
    });

    finishedList.addEventListener('click', function (event) {
        const li = event.target.closest('li');
        if (li) {
            finishedList.removeChild(li);
        }
    });
});
