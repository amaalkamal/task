<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>ToDo App</title>
</head>

<body>
    <div class="container">
        <button id="newBtn" class="btn yellow"> Create </button>
        <button id="doneBtn" class="btn blue">Done</button>
        <button id="deleteBtn" class="btn red">Delete</button>
        <input type="text" id="todoInput" placeholder="Enter your ToDo">
        <ul id="todoList"></ul>
        <ul id="finishedList"></ul>

        <script src="script.js"></script>
    </div>
</body>

</html>