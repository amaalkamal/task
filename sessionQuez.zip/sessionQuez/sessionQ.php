<?php

//problem 4.2

class Person {
    protected string $name;
    protected string $address;

    public function __construct(string $name, string $address) {
        $this->name = $name;
        $this->address = $address;
    }

    public function getname(): string {
        return $this->name;
    }

    public function getadd(): string {
        return $this->address;
    }
    public function setname(string $name): void
    {
        $this->name = $name;
    }
    public function setadd(string $address): void {
        $this->address = $address;

    }
}


Class student extends person {
    private string $program;
    private int $year;
    private float $fee;

    public function __construct(string $name, string $address,string $program, int $year, float $fee)
    {
        parent::__construct($name,$address);
        $this->program=$program;
        $this ->year=$year;
        $this ->fee=$fee;
    }
    public function getprogram(): string {
        return $this->program;
    }

    public function getyear(): string {
        return $this->year;
    }

    public function getfee(): string {
        return $this->fee;
    }
    public function setprogram(string $program): void {
        $this ->program=$program;
    }
    public function setyear(string $year): void {
        $this ->year=$year;
    }
    public function setfee(string $fee):void {
        $this ->fee=$fee;
    }

    public function show(){
        echo " STUDENT IS <br> Name = {$this->name} <br> Address = {$this->address} <br> program = {$this->program} <br> Year = {$this->year} <br> Fee = {$this->fee} <br> <br> <br>";} 
}

Class staff extends person {
    private string $school;
    private float $pay;

    public function __construct(string $name, string $address,string $school, float $pay)
    {
        parent:: __construct($name,$address);
        $this->school =$school;
        $this ->pay =$pay;

    }
    public function getshool():string {
        return $this->school;
    }
    public function getpay():float {
        return $this->pay;
    }
    public function setschool(string $school):void {
        $this->school = $school;
    }
    public function setpay(float $pay):void {
        $this->pay = $pay;
    }

    public function show2(){
        echo " STUFF IS <br> Name = {$this->name} <br> Address = {$this->address} <br> School = {$this->school}  <br> Pay = {$this->pay} ";} 

        // public function getinfo():string {
        //     return ($this->name.$this->address .$this->school .$this->pay);
        // }

}

$std = new student("Aml","Mansoura","CS" ,2000,1500);
$std->show();
$std2 = new staff("Aml","Mansoura","THN school",1000);
$std2->show2();






//------------------------------------------------------------------------------------------------------------------------------------------------------------

//problem 6.1


// abstract class shape {
//     protected string $color;
//     protected bool $fill;

//     public function __construct(string $color, bool $fill) {
//         $this->color = $color;
//         $this->fill = $fill;
//     }

//     public function getcolor(): string {
//         return $this->color;
//     }

//     public function getfill(): bool {
//         return $this->fill;
//     }
//     public function setcolor(string $color): void
//     {
//         $this->color = $color;
//     }
//     public function setfill(bool $fill): void {
//         $this->fill = $fill;

//     }

//     public abstract function getArea() : float;
//     public abstract function getPrimeter() : float;

//     public function display(): string {
//         return " Shape Area = {$this->getArea()} <br> shape Primeter= {$this->getprimeter()}";
//     }
    
// }

// class Circle extends shape {
//     private float $radius;
//     public function __construct(string $color ,bool $fill,float $radius)
//     {
//         parent::__construct($color,$fill);
//     }

//     public function getArea(): float {
//         return pow($this->radius ,2) * pi();
//     }

//     public function getPrimeter(): float {
//         return 2 * $this->radius * pi();
        
//     }

// }

// class Rectangle extends shape {
//     private float $h;
//     private float $w;

//     public function __construct(string $color ,bool $fill,float $h,float $w)
//     {
//         parent::__construct($color,$fill);
//     }
//     public function getArea(): float {
//         return $this->h * $this->w;
//     }
//     public function getPrimeter(): float {
//         return ($this->h + $this->w) * 2;
//     }

// }

// class square extends shape {
//     private float $side;
//     public function __construct(string $color ,bool $fill,float $side){
//         parent::__construct($color,$fill);
//     }
//     public function getArea(): float {
//         return $this->side * $this->side;
//     }
//     public function getPrimeter(): float {
//         return $this->side * 4;
//     }
// }


// $c = new circle("Red",false,5);
// $c->getArea();
// $c->getPrimeter();