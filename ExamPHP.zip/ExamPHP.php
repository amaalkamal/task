<?php
//QUESTION ----------------------------------------------------------------> 1
// 1- 16
// 2-array(2) {
//    ["5"] => 1  ["12"] => 2}

// 3-True


//QUESTION ----------------------------------------------------------------> 2
// 1- 


// function fibonacci($n){
//     $fibonacciSeries = array();
    
//     $fibonacciSeries[0] = 0;
//     $fibonacciSeries[1] = 1;
    
//     for($i = 2; $i < $n; $i++){
//         $fibonacciSeries[$i] = $fibonacciSeries[$i-1] + $fibonacciSeries[$i-2];
//     }
    
//     return $fibonacciSeries;
// }

// $n = 10; 
// $result = fibonacci($n);

// echo "Fibonacci Series for first $n terms: ";
// echo implode(", ", $result);


// 2-

// function isLeapYear($year) {
    
//     return ($year % 4 == 0) && (($year % 100 != 0) || ($year % 400 == 0));
// }

// $year = 2023; 
// if (isLeapYear($year)) {
//     echo "$year is a leap year.";
// } else {
//     echo "$year is not a leap year.";
// }


// 3-


// function generateUniqueRandomNumbers($min, $max, $count) {
//     if ($count > ($max - $min + 1)) {
        
//         return false;
//     }

//     $numbers = range($min, $max);
//     shuffle($numbers);

//     return array_slice($numbers, 0, $count);
// }

// $minRange = 1;
// $maxRange = 50;
// $numberOfRandomNumbers = 10;

// $uniqueRandomNumbers = generateUniqueRandomNumbers($minRange, $maxRange, $numberOfRandomNumbers);

// if ($uniqueRandomNumbers !== false) {
//     echo "Unique Random Numbers within the range $minRange to $maxRange: ";
//     echo implode(", ", $uniqueRandomNumbers);
// } else {
//     echo "Unable to generate unique random numbers with the given count and range.";
// }


// -4

// for ($i = 1; $i < 6; $i++) {
//     for ($j = 1; $j < 6; $j++) {
//        if ($j == 1) {
//          echo str_pad($i*$j, 2, " ", STR_PAD_LEFT);
//        } else {
//          echo str_pad($i*$j, 4, " ", STR_PAD_LEFT);
//        }
//     }
//     echo "<br>";
//   }

// 5-
// function remove_duplicates($list) {
//     $num = array_values(array_unique($list));
//     return $num ;
//   }

//   $nums = array(1,1,2,2,3,3,4,5,5,6 );
//   print_r(remove_duplicates($nums));





// 6-
// Class Animals {
//     protected string $name;

//     public function __construct(string $name) {
//         $this->name = $name;
//     }

//     public function getname(): string {
//         return $this->name;
//     }

//     public function setname(string $name): void
//     {
//         $this->name = $name;
//     }
//     }


// Class mammals extends Animals {

//     public function __construct(string $name)
//     {
//         parent::__construct($name);
//     }

//     public function show(){
//         echo " The Mammal & Animal is <br> Name = {$this->name} <br> <br>";} 
// }

// Class Cats extends mammals {

//     public function __construct(string $name)
//     {
//         parent:: __construct($name);
//     }

//     public function Greet1(){
//         echo "  <br> Name = {$this->name} <br> Says MEOW!<br><br> ";} 

// }

// Class Dogs extends mammals {

//     public function __construct(string $name)
//     {
//         parent:: __construct($name);
//     }

//     public function Greet(){
//         echo " <br> Name = {$this->name} <br> Says WOOF! ";} 


// }


// $ani = new mammals("Cat");
// $ani->show();
// $animal1 = new Cats("Cat");
// $animal1->Greet1();

// $animal2 = new Dogs("Dog");
// $animal2->Greet();

//QUESTION ----------------------------------------------------------------> 3
// 1- True
// 2-False
// 3-True
// 4-True
// 5-True
